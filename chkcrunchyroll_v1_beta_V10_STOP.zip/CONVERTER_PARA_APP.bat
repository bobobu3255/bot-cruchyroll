@echo off
title Criador de Aplicativo Manus Premium
echo ======================================================
echo    CRIANDO EXECUTAVEL (.EXE) DO MANUS PREMIUM
echo ======================================================
echo.
echo 1. Instalando ferramentas necessarias...
pip install pyinstaller customtkinter pillow matplotlib win10toast pystray
echo.
echo 2. Compilando o aplicativo (isso pode levar um momento)...
echo O aplicativo sera criado SEM a janela do CMD (modo silent).
echo.
pyinstaller --noconsole --onefile --name "chkcrunchyroll" gui_app.py
echo.
echo ======================================================
echo CONCLUIDO! 
echo O seu aplicativo esta na pasta "dist" com o nome chkcrunchyroll.exe
echo ======================================================
pause
