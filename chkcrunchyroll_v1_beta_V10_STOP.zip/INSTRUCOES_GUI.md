# Manus Premium Desktop - Crunchyroll Bot GUI

Esta é a interface gráfica (GUI) nativa desenvolvida para o seu bot Crunchyroll. Ela foi construída em Python usando a biblioteca `CustomTkinter` para proporcionar um design **Premium Dark Mode**.

## 🚀 Como Executar

1. **Pré-requisitos**:
   - Python 3.10 ou superior instalado.
   - Node.js instalado (para rodar o script original do bot).

2. **Instalar Dependências da GUI**:
   Abra o terminal na pasta do projeto e execute:
   ```bash
   pip install customtkinter pillow
   ```

3. **Executar o Aplicativo**:
   ```bash
   python gui_app.py
   ```

## 🛠️ Funcionalidades Integradas

- **Dashboard**: Visualize em tempo real o total de contas na fila, cartões aprovados e reprovados.
- **Importação em Lote**: Cole centenas de contas ou cartões diretamente na interface e salve com um clique.
- **Monitor de Logs**: Acompanhe o que o bot está fazendo com mascaramento automático de dados sensíveis para sua segurança.
- **Gestão de Arquivos**: Uma tabela organizada que mostra o status de todos os seus arquivos de dados (`contas.txt`, `cartoes.txt`, `dados.csv`, etc).
- **Configuração de Proxy**: Interface dedicada para gerenciar suas conexões.

## 📁 Estrutura do Projeto
- `gui_app.py`: O executável da interface gráfica.
- `crunchyroll_bot/`: Pasta contendo o seu script original em Node.js.
- `INSTRUCOES_GUI.md`: Este guia.

---
*Desenvolvido com foco em performance e segurança.*
