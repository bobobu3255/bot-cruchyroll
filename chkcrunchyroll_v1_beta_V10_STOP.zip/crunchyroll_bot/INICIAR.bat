@echo off
title Crunchyroll Bot v6.0

echo.
echo ============================================
echo   CRUNCHYROLL BOT v6.0
echo ============================================
echo.

if not exist "node_modules" (
    echo Dependencias nao instaladas!
    echo Execute INSTALAR.bat primeiro.
    echo.
    pause
    exit /b
)

if not exist "data" mkdir data
if not exist "logs" mkdir logs

if exist "contas.txt" if not exist "data\contas.txt" copy contas.txt data\contas.txt >nul
if exist "cartoes.txt" if not exist "data\cartoes.txt" copy cartoes.txt data\cartoes.txt >nul
if exist "dados.csv" if not exist "data\dados.csv" copy dados.csv data\dados.csv >nul

echo Iniciando bot...
echo Pressione S para pular conta, Q para sair.
echo.

node index.js

echo.
echo Bot finalizado.
pause
