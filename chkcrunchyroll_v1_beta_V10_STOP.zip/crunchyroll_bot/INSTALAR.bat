@echo off
title Instalando Crunchyroll Bot v6.0

echo.
echo ============================================
echo   INSTALANDO CRUNCHYROLL BOT v6.0
echo ============================================
echo.

node -v >nul 2>&1
if %errorlevel% neq 0 (
    echo ERRO: Node.js nao encontrado!
    echo.
    echo Instale o Node.js em: https://nodejs.org/
    echo Depois REINICIE o computador e execute novamente.
    echo.
    pause
    exit /b
)

echo Node.js encontrado!
node -v
echo.

if not exist "logs" mkdir logs
if not exist "data" mkdir data

echo Instalando dependencias...
echo Aguarde, pode demorar alguns minutos...
echo.

npm install

if %errorlevel% neq 0 (
    echo.
    echo ERRO na instalacao!
    echo Verifique sua conexao com a internet.
    pause
    exit /b
)

echo.
echo ============================================
echo   INSTALACAO CONCLUIDA!
echo ============================================
echo.
echo Agora execute INICIAR.bat para rodar o bot.
echo.
pause
