#!/bin/bash

echo "============================================"
echo "  INSTALANDO CRUNCHYROLL BOT v6.0 (FSM)"
echo "============================================"
echo ""

# Verificar Node.js
if ! command -v node &> /dev/null; then
    echo "[ERRO] Node.js não encontrado!"
    echo "Instale Node.js 18+ em: https://nodejs.org/"
    exit 1
fi

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
    echo "[ERRO] Node.js versão $NODE_VERSION detectada."
    echo "Este bot requer Node.js 18 ou superior."
    exit 1
fi

echo "[OK] Node.js $(node -v) detectado"
echo ""

# Instalar dependências
echo "[...] Instalando dependências..."
npm install

if [ $? -eq 0 ]; then
    echo ""
    echo "[OK] Dependências instaladas com sucesso!"
    echo ""
    echo "============================================"
    echo "  INSTALAÇÃO CONCLUÍDA!"
    echo "============================================"
    echo ""
    echo "Para iniciar o bot, execute:"
    echo "  ./iniciar.sh"
    echo ""
    echo "Ou:"
    echo "  npm start"
    echo ""
else
    echo ""
    echo "[ERRO] Falha ao instalar dependências."
    exit 1
fi
