#!/bin/bash

echo "============================================"
echo "  CRUNCHYROLL BOT v6.0 - MÁQUINA DE ESTADOS"
echo "============================================"
echo ""
echo "  Pressione 'S' para PULAR conta"
echo "  Pressione 'Q' para SAIR"
echo ""
echo "============================================"
echo ""

# Verificar se node_modules existe
if [ ! -d "node_modules" ]; then
    echo "[AVISO] Dependências não instaladas."
    echo "Executando instalação..."
    ./instalar.sh
fi

# Criar diretório de logs se não existir
mkdir -p logs
mkdir -p data

# Iniciar bot
node index.js
