import customtkinter as ctk
import os
import sys
import threading
import subprocess
import time
from datetime import datetime
import re
import requests

# Configurações de Aparência
ctk.set_appearance_mode("dark")
CRUNCHY_ORANGE = "#F47521"
CRUNCHY_DARK = "#141519"
SUCCESS_GREEN = "#2FA572"
FAIL_RED = "#D35B58"

class App(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("CHKCRUNCHYROLL - v1 beta")
        self.geometry("1300x900")
        self.configure(fg_color=CRUNCHY_DARK)
        
        # Variáveis de Controle
        self.bot_running = False
        self.bot_process = None
        
        # Detectar o diretório base
        if hasattr(sys, '_MEIPASS'):
            base_dir = os.path.dirname(sys.executable)
        else:
            base_dir = os.path.dirname(os.path.abspath(__file__))
            
        potential_bot_path = os.path.join(base_dir, "crunchyroll_bot")
        self.bot_path = potential_bot_path if os.path.exists(potential_bot_path) else base_dir
        self.data_path = os.path.join(self.bot_path, "data")

        # Grid layout
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        # Sidebar
        self.sidebar_frame = ctk.CTkFrame(self, width=220, corner_radius=0, fg_color="#1E1F23")
        self.sidebar_frame.grid(row=0, column=0, sticky="nsew")
        
        self.logo_label = ctk.CTkLabel(self.sidebar_frame, text="CHKCRUNCHYROLL", text_color=CRUNCHY_ORANGE, font=ctk.CTkFont(size=22, weight="bold"))
        self.logo_label.pack(pady=(30, 5))
        self.version_label = ctk.CTkLabel(self.sidebar_frame, text="v1 beta", text_color="grey", font=ctk.CTkFont(size=12))
        self.version_label.pack(pady=(0, 20))

        self.create_menu_button("Dashboard / Resultados", self.show_dashboard)
        self.create_menu_button("Contas e Cartões", self.show_import)
        self.create_menu_button("Monitor de Logs", self.show_logs)
        self.create_menu_button("Configuração Proxy", self.show_proxy)

        # Main Content Area
        self.main_frame = ctk.CTkFrame(self, corner_radius=0, fg_color="transparent")
        self.main_frame.grid(row=0, column=1, sticky="nsew", padx=20, pady=20)
        self.main_frame.grid_columnconfigure(0, weight=1)
        self.main_frame.grid_rowconfigure(0, weight=1)

        self.frames = {}
        self.init_dashboard()
        self.init_import()
        self.init_logs()
        self.init_proxy()

        self.show_dashboard()
        self.load_all_data()
        
        # Thread de atualização de status e teste de proxy
        threading.Thread(target=self.auto_update_loop, daemon=True).start()

    def create_menu_button(self, text, command):
        btn = ctk.CTkButton(self.sidebar_frame, text=text, command=command, height=45, corner_radius=0, fg_color="transparent", text_color="white", hover_color="#323338", anchor="w")
        btn.pack(fill="x", padx=10, pady=2)
        return btn

    def init_dashboard(self):
        frame = ctk.CTkFrame(self.main_frame, fg_color="transparent")
        self.frames["dashboard"] = frame
        
        # Stats Cards
        stats_frame = ctk.CTkFrame(frame, fg_color="transparent")
        stats_frame.pack(fill="x", pady=(0, 20))
        self.card_queue = self.create_stat_card(stats_frame, "Contas na Fila", "0", "#3B8ED0", 0)
        self.card_approved = self.create_stat_card(stats_frame, "Aprovados", "0", SUCCESS_GREEN, 1)
        self.card_failed = self.create_stat_card(stats_frame, "Reprovados", "0", FAIL_RED, 2)
        stats_frame.grid_columnconfigure((0, 1, 2), weight=1)

        # Main Split Area
        split_frame = ctk.CTkFrame(frame, fg_color="transparent")
        split_frame.pack(fill="both", expand=True)
        split_frame.grid_columnconfigure(0, weight=2)
        split_frame.grid_columnconfigure(1, weight=1)

        # Left: Live Results Table
        results_container = ctk.CTkFrame(split_frame, fg_color="#1E1F23", corner_radius=10)
        results_container.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        ctk.CTkLabel(results_container, text="ÚLTIMAS APROVAÇÕES", font=ctk.CTkFont(weight="bold"), text_color=SUCCESS_GREEN).pack(pady=10)
        self.results_list = ctk.CTkTextbox(results_container, fg_color="#141519", font=ctk.CTkFont(family="Consolas", size=11))
        self.results_list.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        # Right: Control Panel
        controls_panel = ctk.CTkFrame(split_frame, fg_color="#1E1F23", corner_radius=10)
        controls_panel.grid(row=0, column=1, sticky="nsew", padx=(10, 0))
        
        ctk.CTkLabel(controls_panel, text="CONTROLES", font=ctk.CTkFont(weight="bold")).pack(pady=20)
        
        # Economia de Dados Switch
        self.economy_mode = ctk.CTkSwitch(controls_panel, text="ECONOMIA DE DADOS (Sem Imagens)", progress_color=CRUNCHY_ORANGE)
        self.economy_mode.select()
        self.economy_mode.pack(pady=10, padx=20, anchor="w")
        
        ctk.CTkLabel(controls_panel, text="Navegadores (Workers):").pack()
        self.worker_slider = ctk.CTkSlider(controls_panel, from_=1, to=10, number_of_steps=9, button_color=CRUNCHY_ORANGE, progress_color=CRUNCHY_ORANGE)
        self.worker_slider.set(3)
        self.worker_slider.pack(padx=20, pady=10, fill="x")
        self.worker_label = ctk.CTkLabel(controls_panel, text="3")
        self.worker_label.pack()
        self.worker_slider.configure(command=lambda v: self.worker_label.configure(text=str(int(v))))

        self.btn_start = ctk.CTkButton(controls_panel, text="INICIAR BOT", height=50, font=ctk.CTkFont(size=16, weight="bold"), fg_color=CRUNCHY_ORANGE, command=self.start_bot)
        self.btn_start.pack(pady=(20, 10), padx=20, fill="x")

        self.btn_stop = ctk.CTkButton(controls_panel, text="PARAR BOT", height=50, font=ctk.CTkFont(size=16, weight="bold"), fg_color=FAIL_RED, command=self.stop_bot, state="disabled")
        self.btn_stop.pack(pady=10, padx=20, fill="x")
        
        self.btn_verificador = ctk.CTkButton(controls_panel, text="RODAR VERIFICADOR", height=40, fg_color="#323338", command=self.run_verificador)
        self.btn_verificador.pack(pady=10, padx=20, fill="x")

    def create_stat_card(self, parent, title, value, color, col):
        card = ctk.CTkFrame(parent, fg_color="#1E1F23", corner_radius=10)
        card.grid(row=0, column=col, padx=5, sticky="nsew")
        ctk.CTkLabel(card, text=title, font=ctk.CTkFont(size=13), text_color="#A0A0A0").pack(pady=(10, 0))
        val_lbl = ctk.CTkLabel(card, text=value, font=ctk.CTkFont(size=28, weight="bold"), text_color=color)
        val_lbl.pack(pady=(0, 10))
        card.value_label = val_lbl
        return card

    def init_import(self):
        frame = ctk.CTkFrame(self.main_frame, fg_color="transparent")
        self.frames["import"] = frame
        tabview = ctk.CTkTabview(frame, segmented_button_selected_color=CRUNCHY_ORANGE)
        tabview.pack(fill="both", expand=True)
        self.txt_accounts = self.create_data_tab(tabview, "Contas (email:senha)", "contas.txt")
        self.txt_cards = self.create_data_tab(tabview, "Cartões", "cartoes.txt")
        self.txt_premium = self.create_data_tab(tabview, "Premium (Simples)", "contas_premium_simples.txt", readonly=True)

    def create_data_tab(self, tabview, name, filename, readonly=False):
        tab = tabview.add(name)
        txt = ctk.CTkTextbox(tab, fg_color="#141519", font=ctk.CTkFont(family="Consolas", size=12))
        txt.pack(fill="both", expand=True, padx=10, pady=10)
        btn_frame = ctk.CTkFrame(tab, fg_color="transparent")
        btn_frame.pack(fill="x", padx=10, pady=5)
        ctk.CTkButton(btn_frame, text="Recarregar", width=120, command=lambda: self.load_file_to_text(filename, txt)).pack(side="left", padx=5)
        if not readonly:
            ctk.CTkButton(btn_frame, text="Salvar", width=120, fg_color=CRUNCHY_ORANGE, command=lambda: self.save_data(filename, txt)).pack(side="left", padx=5)
        return txt

    def init_logs(self):
        frame = ctk.CTkFrame(self.main_frame, fg_color="transparent")
        self.frames["logs"] = frame
        self.log_text = ctk.CTkTextbox(frame, font=ctk.CTkFont(family="Consolas", size=11), fg_color="#141519")
        self.log_text.pack(fill="both", expand=True)
        ctk.CTkButton(frame, text="Limpar Logs", command=lambda: self.log_text.delete("1.0", "end")).pack(pady=10)

    def init_proxy(self):
        frame = ctk.CTkFrame(self.main_frame, fg_color="transparent")
        self.frames["proxy"] = frame
        
        # Proxy Status Indicator
        status_frame = ctk.CTkFrame(frame, fg_color="#1E1F23", corner_radius=10)
        status_frame.pack(pady=(0, 20), fill="x")
        self.proxy_status_led = ctk.CTkLabel(status_frame, text="●", text_color="grey", font=ctk.CTkFont(size=24))
        self.proxy_status_led.pack(side="left", padx=20, pady=10)
        self.proxy_status_text = ctk.CTkLabel(status_frame, text="Status do Proxy: Aguardando Teste", font=ctk.CTkFont(weight="bold"))
        self.proxy_status_text.pack(side="left", pady=10)

        form = ctk.CTkFrame(frame, fg_color="#1E1F23", corner_radius=10)
        form.pack(pady=0, padx=0, fill="both", expand=True)
        
        ctk.CTkLabel(form, text="CONFIGURAÇÃO DE PROXY ROTATIVO", font=ctk.CTkFont(weight="bold"), text_color=CRUNCHY_ORANGE).pack(pady=20)
        
        self.proxy_active = ctk.CTkSwitch(form, text="Ativar Uso de Proxy", progress_color=CRUNCHY_ORANGE)
        self.proxy_active.pack(pady=10, padx=30, anchor="w")

        ctk.CTkLabel(form, text="Proxy Host:Porta (ou Link de Rotação):").pack(padx=30, anchor="w")
        self.proxy_url = ctk.CTkEntry(form, width=500, placeholder_text="ex: br.smartproxy.com:10000")
        self.proxy_url.pack(padx=30, pady=5, anchor="w")

        ctk.CTkLabel(form, text="Usuário (opcional):").pack(padx=30, anchor="w")
        self.proxy_user = ctk.CTkEntry(form, width=300)
        self.proxy_user.pack(padx=30, pady=5, anchor="w")

        ctk.CTkLabel(form, text="Senha (opcional):").pack(padx=30, anchor="w")
        self.proxy_pass = ctk.CTkEntry(form, width=300, show="*")
        self.proxy_pass.pack(padx=30, pady=5, anchor="w")

        btn_frame = ctk.CTkFrame(form, fg_color="transparent")
        btn_frame.pack(pady=30, padx=30, fill="x")
        ctk.CTkButton(btn_frame, text="Testar Conexão", width=150, command=self.test_proxy).pack(side="left", padx=5)
        ctk.CTkButton(btn_frame, text="Salvar Configuração", width=150, fg_color=CRUNCHY_ORANGE, command=self.save_proxy_config).pack(side="left", padx=5)

    def test_proxy(self):
        self.proxy_status_text.configure(text="Testando conexão...")
        self.proxy_status_led.configure(text_color="orange")
        
        def run_test():
            proxy_addr = self.proxy_url.get().strip()
            if not proxy_addr:
                self.after(0, lambda: self.update_proxy_status(False, "Nenhum proxy configurado"))
                return
            
            user = self.proxy_user.get().strip()
            pw = self.proxy_pass.get().strip()
            
            proxies = None
            if proxy_addr:
                if user and pw:
                    p_str = f"http://{user}:{pw}@{proxy_addr}"
                else:
                    p_str = f"http://{proxy_addr}"
                proxies = {"http": p_str, "https": p_str}
            
            try:
                r = requests.get("https://api.ipify.org?format=json", proxies=proxies, timeout=10)
                ip = r.json().get("ip")
                self.after(0, lambda: self.update_proxy_status(True, f"Conectado! IP: {ip}"))
            except Exception as e:
                self.after(0, lambda: self.update_proxy_status(False, f"Falha na conexão: {str(e)[:50]}..."))
        
        threading.Thread(target=run_test, daemon=True).start()

    def update_proxy_status(self, success, msg):
        self.proxy_status_led.configure(text_color=SUCCESS_GREEN if success else FAIL_RED)
        self.proxy_status_text.configure(text=f"Status do Proxy: {msg}")

    def save_proxy_config(self):
        # Aqui você salvaria as configs em um JSON ou .env que o bot lê
        print("Proxy Salvo!")

    def show_dashboard(self): self.show_frame("dashboard")
    def show_import(self): self.load_all_data(); self.show_frame("import")
    def show_logs(self): self.show_frame("logs")
    def show_proxy(self): self.show_frame("proxy")

    def show_frame(self, name):
        for f in self.frames.values(): f.grid_forget()
        self.frames[name].grid(row=0, column=0, sticky="nsew")

    def load_file_to_text(self, filename, textbox):
        path = os.path.join(self.data_path, filename)
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                content = f.read()
                textbox.delete("1.0", "end")
                textbox.insert("1.0", content)

    def load_all_data(self):
        self.load_file_to_text("contas.txt", self.txt_accounts)
        self.load_file_to_text("cartoes.txt", self.txt_cards)
        self.load_file_to_text("contas_premium_simples.txt", self.txt_premium)
        self.update_results_list()

    def save_data(self, filename, textbox):
        path = os.path.join(self.data_path, filename)
        content = textbox.get("1.0", "end-1c")
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)

    def toggle_bot(self):
        if not self.bot_running: self.start_bot()
        else: self.stop_bot()

    def start_bot(self):
        self.bot_running = True
        self.btn_start.configure(state="disabled")
        self.btn_stop.configure(state="normal")
        self.show_logs()
        
        workers = str(int(self.worker_slider.get()))
        economy = "true" if self.economy_mode.get() else "false"
        
        def run():
            try:
                env = os.environ.copy()
                env["NUM_WORKERS"] = workers
                env["ECONOMY_MODE"] = economy
                
                # Configurar proxy se ativo
                if self.proxy_active.get():
                    env["PROXY_ENABLED"] = "true"
                    env["PROXY_HOST"] = self.proxy_url.get().split(":")[0] if ":" in self.proxy_url.get() else self.proxy_url.get()
                    env["PROXY_PORT"] = self.proxy_url.get().split(":")[1] if ":" in self.proxy_url.get() else ""
                    env["PROXY_USERNAME"] = self.proxy_user.get()
                    env["PROXY_PASSWORD"] = self.proxy_pass.get()

                self.bot_process = subprocess.Popen(
                    "node index.js", cwd=self.bot_path, env=env,
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    shell=True, text=True, bufsize=1, universal_newlines=True,
                    encoding='utf-8', errors='replace'
                )
                for line in iter(self.bot_process.stdout.readline, ''):
                    if not self.bot_running: break
                    self.log_text.insert("end", line)
                    self.log_text.see("end")
                    if "premium" in line.lower() or "sucesso" in line.lower():
                        self.after(0, self.load_all_data)
                self.bot_process.stdout.close()
                self.bot_process.wait()
            except Exception as e:
                self.log_text.insert("end", f"\nERRO: {str(e)}\n")
            finally:
                self.after(0, self.on_bot_stopped)
        threading.Thread(target=run, daemon=True).start()

    def stop_bot(self):
        self.bot_running = False
        if self.bot_process: self.bot_process.terminate()

    def on_bot_stopped(self):
        self.bot_running = False
        self.btn_start.configure(state="normal")
        self.btn_stop.configure(state="disabled")

    def run_verificador(self):
        self.show_logs()
        self.log_text.insert("end", "\n>>> INICIANDO VERIFICADOR...\n")
        def run():
            subprocess.run(["node", "verificador.js"], cwd=self.bot_path, shell=True)
            self.after(0, self.load_all_data)
        threading.Thread(target=run, daemon=True).start()

    def auto_update_loop(self):
        while True:
            try:
                q = self.count_lines("contas.txt")
                a = self.count_lines("cartoes_aprovados.txt")
                f = self.count_lines("cartoes_falhos.txt")
                self.after(0, lambda: self.update_stats(q, a, f))
            except: pass
            time.sleep(5)

    def count_lines(self, filename):
        path = os.path.join(self.data_path, filename)
        if not os.path.exists(path): return 0
        with open(path, "r", encoding="utf-8") as f:
            return len([l for l in f if l.strip()])

    def update_stats(self, q, a, f):
        self.card_queue.value_label.configure(text=str(q))
        self.card_approved.value_label.configure(text=str(a))
        self.card_failed.value_label.configure(text=str(f))

    def update_results_list(self):
        path = os.path.join(self.data_path, "contas_premium_simples.txt")
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                lines = f.readlines()[-20:]
                self.results_list.delete("1.0", "end")
                for l in reversed(lines):
                    self.results_list.insert("end", f"✅ {l}")

if __name__ == "__main__":
    app = App()
    app.mainloop()
